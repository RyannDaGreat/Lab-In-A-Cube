#Change Logs


## 1.1.3 - Saturday, 12 December 07 : 35 : 39 (GMT 00:00)
- [7bd6566](../../commit/7bd6566) add onPointLock, onExitPointLock

## 1.1.2
- [bbffd9c](../../commit/bbffd9c) build format change commonjs -> [umd](https://github.com/rollup/rollup/wiki/JavaScript-API#format)  

## 1.1.1 - Monday, 07 December 13 : 10 : 19 (GMT 00:00)
- [faf122d](../../commit/faf122d) build script fix
- [faf122d](../../commit/faf122d) badge using [shields](https://github.com/badges/shields)
- [faf122d](../../commit/faf122d) add jsnext:main field [jsnext:main](https://github.com/rollup/rollup/wiki/jsnext:main)

## 1.1.0 - Monday, 07 December 11 : 45 : 56 (GMT 00:00)
- [6f3f214](../../commit/6f3f214) can't using build js file so build tools change [webpack](https://webpack.github.io/) -> [rollupjs](http://rollupjs.org/)
